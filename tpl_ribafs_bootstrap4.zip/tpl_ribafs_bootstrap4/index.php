<?php
/**
* @Package: Bootstrap
* @copyright Copyright (C) 2017 Ribamar FS. All rights reserved.
* @index.php
* 
*/

// no direct access
defined('_JEXEC') or die;

$path = JURI::base().'/templates/'.$this->template;
$doc = JFactory::getDocument();

$template = JFactory::getApplication()->getTemplate(true);
$params   = $template->params;

$apreTitulo = $params->get('apreTitulo');
$apreDescricao = $params->get('apreDescricao');
$objetivo = $params->get('objetivo');
$objetivoDescricao = $params->get('objetivoDescricao');
$gratuitos = $params->get('gratuitos');
?>

<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />	
	<jdoc:include type="head" />
	<?php
		$doc->addStyleSheet('templates/' . $this->template . '/vendor/bootstrap/css/bootstrap.min.css');
		$doc->addStyleSheet('templates/' . $this->template . '/vendor/font-awesome/css/font-awesome.min.css');
		$doc->addStyleSheet('templates/' . $this->template . '/vendor/magnific-popup/magnific-popup.css');
		$doc->addStyleSheet('templates/' . $this->template . '/css/creative.min.css');
		$doc->addStyleSheet('templates/' . $this->template . '/css/template.css');
        $img = 'templates/' . $this->template . '/img/';
	?>	
</head>

<body id="page-top">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      <div class="container">
		<div class="span4 navbar-brand js-scroll-trigger">
			<a href="index.php"><jdoc:include type="modules" name="logo" style="none" /></a>
		</div>

        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <nav class="navbar-nav ml-auto">
			<jdoc:include type="modules" name="menu" style="none" />
		  </nav>
        </div>
      </div><!-- / container -->
    </nav>

    <header class="masthead">
      <div class="header-content">
        <div class="header-content-inner">
          <h1 id="homeHeading"><?=$apreTitulo?></h1>
          <hr>
          <p><?=$apreDescricao?></p>
          <a class="btn btn-primary btn-xl js-scroll-trigger" href="#objetivo">Vá em Frente</a>
        </div>
      </div>
    </header>

    <section class="bg-primary" id="objetivo">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
            <h2 class="section-heading text-white"><?=$objetivo?></h2>
            <hr class="light">
            <p class="text-faded"><?=$objetivoDescricao?></p>
            <a class="btn btn-default btn-xl js-scroll-trigger" href="#gratuitos">Bola pra Frente!</a>
          </div>
        </div>
      </div>
    </section>

    <section id="gratuitos">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading"><?=$gratuitos?></h2>
            <hr class="primary">
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
              <i class="fa fa-4x fa-server text-primary sr-icons"></i>
              <h3>Servidores</h3>
              <p class="text-muted">Servidor Web e Servidor SGBD.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
              <i class="fa fa-4x fa-joomla text-primary sr-icons"></i>
              <h3>CMS</h3>
              <p class="text-muted">Joomla, Virtuemart e outros!</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
              <i class="fa fa-4x fa-database text-primary sr-icons"></i>
              <h3>SGBD</h3>
              <p class="text-muted">MySQL e PostgreSQL.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
              <i class="fa fa-4x fa-info-circle text-primary sr-icons"></i>
              <h3>PHP, CSS e Cia</h3>
              <p class="text-muted">Desenvolvimento Web em geral!</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="p-0" id="portfolio">
      <div class="container-fluid">
        <div class="row no-gutter popup-gallery">
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?=$img?>portfolio/fullsize/1.jpg">
              <img class="img-fluid" src="<?=$img?>portfolio/thumbnails/1.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?=$img?>portfolio/fullsize/2.jpg">
              <img class="img-fluid" src="<?=$img?>portfolio/thumbnails/2.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?=$img?>portfolio/fullsize/3.jpg">
              <img class="img-fluid" src="<?=$img?>portfolio/thumbnails/3.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?=$img?>portfolio/fullsize/4.jpg">
              <img class="img-fluid" src="<?=$img?>portfolio/thumbnails/4.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?=$img?>portfolio/fullsize/5.jpg">
              <img class="img-fluid" src="<?=$img?>portfolio/thumbnails/5.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-6">
            <a class="portfolio-box" href="<?=$img?>portfolio/fullsize/6.jpg">
              <img class="img-fluid" src="<?=$img?>portfolio/thumbnails/6.jpg" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category text-faded">
                    Category
                  </div>
                  <div class="project-name">
                    Project Name
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>

    <section id="contato">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
            <h2 class="section-heading">Contato!</h2>
            <hr class="primary">
            <p>Ready to start your next project with us? That's great! Give us a call or send us an email and we will get back to you as soon as possible!</p>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-4 ml-auto text-center">
            <i class="fa fa-phone fa-3x sr-contact"></i>
            <p>123-456-6789</p>
          </div>
          <div class="col-lg-4 mr-auto text-center">
            <i class="fa fa-envelope-o fa-3x sr-contact"></i>
            <p>
              <a href="mailto:your-email@your-domain.com">feedback@startbootstrap.com</a>
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="<?=$path?>/vendor/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="<?=$path?>/vendor/popper/popper.min.js"></script>
    <script type="text/javascript" src="<?=$path?>/vendor/bootstrap/js/bootstrap.min.js"></script>
        <!-- Plugin JavaScript-->
    <script type="text/javascript" src="<?=$path?>/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script type="text/javascript" src="<?=$path?>/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script type="text/javascript" src="<?=$path?>/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
        <!-- Custom scripts for this template -->
    <script type="text/javascript" src="<?=$path?>/js/creative.min.js"></script>
	<jdoc:include type="modules" name="debug" style="none" />
</body>
</html>
